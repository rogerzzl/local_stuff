# OOSA TASK1

TASK1 is to develop a script for processing LVIS data to DEM. The script contains a command line parser to input filename and resolution.
There are four *py* files

```
lvisClass.py
processLVIS.py
handleTiff.py
task1_main.py
```

## lvisClass.py

This *py* file contains a clss called **lvisData** to read LVIS data, and some methods to set elevation and bounds of interest area. Methods are:
```
readLVIS(): contains variables like filename,minX,minY,maxX,maxY,etc. to read LVIS data.
          set a variable useInd to focus on, and if no data in useInd, return a False value.
setElevation(): produces an array z of evevations per waveform bin
...
```
example:
```
#import packages
from lvisClass import lvisData

bounds = lvisData(filename,onlyBounds=True)
#set bounds
x0 = bounds[0]
y0 = bounds[1]
x1 = (bounds[2]-minX)/2 + minX
y1 = (bounds[2]-minY)/2 + minY
#read data
lvis = lvisData(filename,minX=x0,minY=y0,maxX=x1,maxY=y1)
```
This example set a bounds about a quarter.

## processLVIS.py
This *py* file contains a clss called **lvisGround** to process lvis data,which inherits from lvisData in *lvisClass.py*. Methods are:
```
estimateGround(): processes waveforms to estimate ground
setThreshold(): set a noise threshold
CofG(): find centre of gravity
reproject(): reproject the results after reading lvis data
findStats(): find mean of noise and standard deviation
denoise(): denoise waveform data
```
example:
```
#import packages
from processLVIS import lvisGround

lvis = lvisGround(filename)
lvis.setElevation()
lvis.estimateGround()
```
lvisGround contains many methods to process LVIS data, and the *estimateGround()* method may take a long time.

## tiffHandle.py
This *py* file contains a clss called **Transform** to handle tiff files with writing and reading. methods are:
```
writeTiff(): write points data into a geotiff file
readTiff(): read a geotiff file into RAM
```
example:
```
#import packages
from tiffHandle import Transform

b = Transform(filename)
b.writeTiff()
```


## task1_main.py
This *py* file is the main function part and contains a command line parser function.
Methods are:
```
readCommands(): contains 3 main arguments like input, output, and res.
```
And in main part add a loop to writeTiff:
```
for i in range(15):
        for j in range(15):
            #get data
            b = lvisData(filename,onlyBounds=True)
            #divide into 15 parts
            x0 = (b.bounds[2]-b.bounds[0])*i/15+b.bounds[0]
            y0 = (b.bounds[3]-b.bounds[1])*j/15+b.bounds[1]
            x1=(b.bounds[2]-b.bounds[0])*(i+1)/15+b.bounds[0]
            y1=(b.bounds[3]-b.bounds[1])*(j+1)/15+b.bounds[1]


            # read in bounds
            lvis=lvisGround(filename,minX=x0,minY=y0,maxX=x1,maxY=y1)
            #get value when readLVIS data
            a = lvis.readLVIS(filename,minX=x0,minY=y0,maxX=x1,maxY=y1,onlyBounds=False)
            #if readLVIS return 'a' value means LVIS data have data
            if (a):
                #print the coordinate in 15*15 grid
                print([i,j])
                #reroject the result, 3031 is a Antartica metric projection
                lvis.reproject(4326,3031)
                #process lvis data to get useful spatial information
                lvis.setElevations()
                data=lvis.estimateGround()
                #write a tiff file
                b=Transform(filename)
                b.writeTiff(data,lvis.lon,lvis.lat,res,outname=outname+str(i)+str(j)+'.tif')

            else:
                #if readLVIS return a opposite 'a' value
                print('No data')
```
This loop mainly uses for finding nodata part and avoiding RAM killed.
And user can run this *py* in terminal by command line to choose input file, output filename, and resolution:
```
python3 task1_main.py --input filename --output outname --res 10
```

## 2009.txt & 2015.txt
Two txt files contain the HDF5 file name in 2009 and 2015.

## 2009.sh & 2015.sh
Two shell script that can achieve batch processing.
Example:
```
while read p;
do
   python3 task1_main.py --input "/geos/netdata/avtrain/data/3d/oosa/assignment/lvis/2009/$p" --output "$p" --res 100
done <2009.txt
```
It will process all the data in 2009 file folder.

# OOSA TASK 2

TASK2 is to develop a script to process all data in 2015 and achieve gap-fill function.
There are five *py* files:
```
lvisClass.py #the same as TASK1
processLVIS.py #the same as TASK1
handleTiff.py #the same as TASK1
task2_merge.py
task2_gapfill.py
```
Due to the same file in TASK1, here just introduces two different *py* files
## task2_merge.py

This *py* file uses to merge tiff files. And it contains a function to write tiff files.
example:
```
zG = []
    #use new lon to hold all lon values in a 15*15 image
    lon = []
    #use new lon to hold all lon values in a 15*15 image
    lat = []
    #loop 15 times
    for i in range(15):
        for j in range(15):
            #get data
            b = lvisData(filename,onlyBounds=True)
            #divide into 15 parts
            x0 = (b.bounds[2]-b.bounds[0])*i/15+b.bounds[0]
            y0 = (b.bounds[3]-b.bounds[1])*j/15+b.bounds[1]
            x1=(b.bounds[2]-b.bounds[0])*(i+1)/15+b.bounds[0]
            y1=(b.bounds[3]-b.bounds[1])*(j+1)/15+b.bounds[1]
            # read in bounds
            lvis=lvisGround(filename,minX=x0,minY=y0,maxX=x1,maxY=y1)
            #get value when readLVIS data
            a = lvis.readLVIS(filename,minX=x0,minY=y0,maxX=x1,maxY=y1,onlyBounds=False)
            #if readLVIS return 'a' value means LVIS data have data
            if (a):
                #print the coordinate in 15*15 grid
                print([i,j])
                #reroject the result, 3031 is a Antartica metric projection
                lvis.reproject(4326,3031)
                #process lvis data to get useful spatial information
                lvis.setElevations()
                data = lvis.estimateGround()
                #write a tiff file
                b = Transform(filename)
                #add all zG into this zG
                zG = np.append(zG,lvis.zG)
                #add all lon into this lon
                lon = np.append(lon,lvis.lon)
                #add all lat into this lat
                lat = np.append(lat,lvis.lat)
            else:

                #if readLVIS return a opposite 'a' value
                print('No data')
    #write a tiff for total zG,total lon,total lat values
    writeTiff(zG,lon,lat,res=200,outname=outname+str(i)+str(j)+'.tif')
```
This example shows that it will merge those small tiff in 15*15 parts together.

## task2_gapfill.py
This *py* file contains functions:
- raster2array()
- getNoDataValue()
- array2raster()

example:
```
def raster2array(rasterfn):  # a method to open tiff and get values as an array
    # open tiff
    raster = gdal.Open(rasterfn)
    #get the band 1 information, actually the defult band in the tiff is 1
    band = raster.GetRasterBand(1)
    # give a return value as an array
    return band.ReadAsArray()
############################################################################

def getNoDataValue(rasterfn): # a method to get nodata part in tiff
    # open tiff
    raster = gdal.Open(rasterfn)
    band = raster.GetRasterBand(1)
    # use GetNoDataValue to get no data
    return band.GetNoDataValue()

```
So use once find out the GetNoDataValue, new values can be used into replace the no data values.
```
# Convert Raster to array
rasterArray = raster2array(rasterfn)

# Get no data value of array
noDataValue = getNoDataValue(rasterfn)

# Updata no data value in array with new value
rasterArray[rasterArray == noDataValue] = newValue
```
## 2015.sh & 2015_merge folder
- 2015.sh: the batch processing to merge images
- 2015_merge: the folder includes the results after merge data.


note: Due to the efficiency of processing, only use some images in 2015 which have junction with 2009 images in the merge part.

# OOSA TASK 3
The aim of TASK3 is using a script to find intersection parts between 2009 and 2015 images. It contains two *py* files:
- task3_intersection.py
- task3_pseudoCode.py

# task3_intersection.py
This *py* file contains a probably solution to raster overlap. use two tiff files in 2009 and 2015 to find the junction parts.
example:
```
    '''
    intersection part
    '''
    # find a intersection in a particular rigion,set r1 and r2
    r1 = [gt1[0], gt1[3],gt1[0] + (gt1[1] * tiff1.RasterXSize), gt1[3] + (gt1[5] * tiff1.RasterYSize)]
    r2 = [gt2[0], gt2[3],gt2[0] + (gt2[1] * tiff2.RasterXSize), gt2[3] + (gt2[5] * tiff2.RasterYSize)]
    #get the intersection by max and min in the rigions,and save as a list
    intersection = [max(r1[0], r2[0]), min(r1[1], r2[1]), min(r1[2], r2[2]), max(r1[3], r2[3])]
    #give these values in intersection list to xmin,xmax,ymin,ymax
    xmin = intersection[0]
    xmax = intersection[2]
    ymin = intersection[3]
    ymax = intersection[1]

    # Specify offset and rows and columns to read
    xoff = int((xmin - xOrigin)/pixelWidth)
    yoff = int((yOrigin - ymax)/pixelWidth)
    xcount = int((xmax - xmin)/pixelWidth)+1
    ycount = int((ymax - ymin)/pixelWidth)+1
    srs=tiff1.GetProjectionRef() #necessary to export with SRS
    #set the output format
    target_ds = gdal.GetDriverByName('MEM').Create('', xcount, ycount, 1, gdal.GDT_Byte)
    target_ds.SetGeoTransform((xmin, pixelWidth, 0,ymax, 0, pixelHeight,))
    #get the arrays in two tiff files
    img1 = tiff1.ReadAsArray(xoff, yoff, xcount, ycount)  
    img2 = tiff2.ReadAsArray(xoff, yoff, xcount, ycount)
    #print intersection to see the coordinate range of the intersection
    print(intersection)
```
Using a contain relation to find the minx,miny,maxX,maxY to determine the intersection junction parts.

## task3_pseudoCode.py

Due to the uncomplete results in *task3_intersection.py*, this *py* file use a pseudo code to give a possible solution to raster overlap.
example:
```
def adjust(self,raster1,raster2):
    '''
    a function for adjuest the direction of x axis if it is diffferent in two tiff rasters
    '''
    if direction_x_raster1 != direction_x_raster2:
        #adjust to ensure the direction of rasters is the same
        adjust raster1 & raster2
############################################################################

def findIntersection(self,i,j,x_real,y_real):
    '''
    i,j is the x,y in pixel coordinate system
    x_real is x value in real projection
    y_real is y value in real projection
    '''
    #x_real1 is real x for tiff file 1
    x_real1 = raster1.x
    #y_real1 is real y for tiff file 1
    y_real1 = raster1.y
    #x_real2 is real x for tiff file 2
    x_real2 = raster2.x
    #y_real2 is real y for tiff file 2
    y_real2 = raster2.y
    #pixel size in x direction in tiff file 1
    pixelX = np.size(x_real1)
    #pixel size in y direction in tiff file 1
    pixelY = np.size(y_real1)
    # make a loop
    for i in range(pixel_X):
        for j in range(pixelY):
            # if the lower left point in tiff file 2 is included in tiff file 2
            if (x_real2>x_real1 & x_real2<x_real1+i & y_real2>y_real1 & y_real2<y_real1+j):
                #get the lower left coordinate of tiff file 2
                print(x_real2,y_real2)
                return x_real2,x_real1+i,y_real2,yreal1+j
############################################################################
```

# OOSA TASK 4
TASK 4 needs to find a solution to draw contours in the intersection part. It contains two *py* files:
- task4_test.py
- task4_pseudoCode.py

## task4_test.py
This *py* file contains a solution to transform raster to shape file. Although it is not the solution to draw contour lines, some thoughts are useful in raster and contour line shape operation.
example:
```
def array2shp(array,outSHPfn,rasterfn,pixelValue):
    '''
    a function transform array to shape file
    '''
    # max distance between points
    raster = gdal.Open(rasterfn)
    geotransform = raster.GetGeoTransform()
    pixelWidth = geotransform[1]
    maxDistance = ceil(sqrt(2*pixelWidth*pixelWidth))
    print(maxDistance)

    # array2dict
    count = 0
    #make a judgemet here
    roadList = np.where(array == pixelValue)
    multipoint = ogr.Geometry(ogr.wkbMultiLineString)
    #use a dictionary to store these values
    pointDict = {}
    for indexY in roadList[0]:
        indexX = roadList[1][count]
        Xcoord, Ycoord = pixelOffset2coord(rasterfn,indexX,indexY)
        pointDict[count] = (Xcoord, Ycoord)
        count += 1

    # dict2wkbMultiLineString
    multiline = ogr.Geometry(ogr.wkbMultiLineString)
    #loop to add values
    for i in itertools.combinations(pointDict.values(), 2):
        point1 = ogr.Geometry(ogr.wkbPoint)
        point1.AddPoint(i[0][0],i[0][1])
        point2 = ogr.Geometry(ogr.wkbPoint)
        point2.AddPoint(i[1][0],i[1][1])

        distance = point1.Distance(point2)
        # judging by distance
        if distance < maxDistance:
            line = ogr.Geometry(ogr.wkbLineString)
            line.AddPoint(i[0][0],i[0][1])
            line.AddPoint(i[1][0],i[1][1])
            multiline.AddGeometry(line)

    # wkbMultiLineString2shp
    shpDriver = ogr.GetDriverByName("ESRI Shapefile")
    if os.path.exists(outSHPfn):
        shpDriver.DeleteDataSource(outSHPfn)
    outDataSource = shpDriver.CreateDataSource(outSHPfn)
    outLayer = outDataSource.CreateLayer(outSHPfn, geom_type=ogr.wkbMultiLineString )
    featureDefn = outLayer.GetLayerDefn()
    outFeature = ogr.Feature(featureDefn)
    outFeature.SetGeometry(multiline)
    outLayer.CreateFeature(outFeature)
```
This function uses to draw shape file by array,so it can be used into transforming array to contour Shapefile.

## task4_pseudoCode.py
This is a pseudo code contains a possible method to solve drawing contour lines.
example:
```
def drawContour(x,y):
    '''
    a function to draw contour line
    '''
    #set a draw start point
    if x is smallest than other x in same pixel value:
        start_x = x
    # append new x values
    total_x = np.append(x,samevalue x)
    plt.plot(start_x,total_x)

def DP_line(ix,iy,x,y,node):
    '''
    line generalisation function
    '''
    #check the whether points are adjacent,if yes,stop
    if ix-iy < 2:
        return
    #calculate the distance between points and each line.
    distacne(x,y,line)
    #find the max distance
    maxDis = np.max(distance)
    #if distance beyond tolerance,add a node
    if maxDis biger:
        #add node
        add a node
        #print node and coordinate
        print(node,x,y)
        # append node
        node = np.append(node)
        #generate those nodes
        DP_line(x,y,node)
```
The key to draw contour lines is to find the same values in the DEM raster, and draw them in a regular way, and can use Douglas-Peucker line generalisation thoughts to generalize the lines.
