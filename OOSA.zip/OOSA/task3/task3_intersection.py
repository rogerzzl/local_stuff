#a example for get inersection in two raster data
'''
import packages
'''
import numpy as np
from osgeo import gdal  
 

#######################################################
if __name__=="__main__":
    # input tiff file
    tiff1 = gdal.Open('ILVIS1B_AQ2009_1020_R1408_058456.h51414.tif')
    # input another tiff file
    tiff2 = gdal.Open('ILVIS1B_AQ2015_1017_R1605_058236.h51414.tif')
    #get the transform information
    gt1 = tiff1.GetGeoTransform()
    gt2 = tiff2.GetGeoTransform()
    if gt1[0] < gt2[0]:#CONDITIONAL TO SELECT THE CORRECT ORIGIN
        gt3=gt2[0]
    else:
        gt3=gt1[0]
    if gt1[3] < gt2[3]:
        gt4=gt1[3]
    else:
        gt4=gt2[3]
    #get the origin x and y
    xOrigin = gt3
    yOrigin = gt4
    # get pixel width and Height 
    pixelWidth = gt1[1]
    pixelHeight = gt1[5]
    '''
    intersection part
    '''
    # find a intersection in a particular rigion,set r1 and r2
    r1 = [gt1[0], gt1[3],gt1[0] + (gt1[1] * tiff1.RasterXSize), gt1[3] + (gt1[5] * tiff1.RasterYSize)]
    r2 = [gt2[0], gt2[3],gt2[0] + (gt2[1] * tiff2.RasterXSize), gt2[3] + (gt2[5] * tiff2.RasterYSize)]
    #get the intersection by max and min in the rigions,and save as a list
    intersection = [max(r1[0], r2[0]), min(r1[1], r2[1]), min(r1[2], r2[2]), max(r1[3], r2[3])]
    #give these values in intersection list to xmin,xmax,ymin,ymax
    xmin = intersection[0]
    xmax = intersection[2]
    ymin = intersection[3]
    ymax = intersection[1]
    
    # Specify offset and rows and columns to read
    xoff = int((xmin - xOrigin)/pixelWidth)
    yoff = int((yOrigin - ymax)/pixelWidth)
    xcount = int((xmax - xmin)/pixelWidth)+1
    ycount = int((ymax - ymin)/pixelWidth)+1
    srs=tiff1.GetProjectionRef() #necessary to export with SRS
    #set the output format
    target_ds = gdal.GetDriverByName('MEM').Create('', xcount, ycount, 1, gdal.GDT_Byte)
    target_ds.SetGeoTransform((xmin, pixelWidth, 0,ymax, 0, pixelHeight,))
    #get the arrays in two tiff files
    img1 = tiff1.ReadAsArray(xoff, yoff, xcount, ycount)  
    img2 = tiff2.ReadAsArray(xoff, yoff, xcount, ycount) 
    #print intersection to see the coordinate range of the intersection
    print(intersection)
