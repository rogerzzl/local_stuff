'''
import packages here
'''
from osgeo import gdal  
import numpy as np
 
############################################################################
class task3(object):
    def __init__(self,filename):
        self.filename = filename
############################################################################
    def readTiff(self,filename,epsg=3031):
        '''
        Read a geotiff in to RAM
        '''
        
        # open a dataset object
        ds=gdal.Open(filename)
        # could use gdal.Warp to reproject if wanted?
    
        # read data from geotiff object
        self.nX=ds.RasterXSize             # number of pixels in x direction
        self.nY=ds.RasterYSize             # number of pixels in y direction
        # geolocation tiepoint
        transform_ds = ds.GetGeoTransform()# extract geolocation information
        self.xOrigin=transform_ds[0]       # coordinate of x corner
        self.yOrigin=transform_ds[3]       # coordinate of y corner
        self.pixelWidth=transform_ds[1]    # resolution in x direction
        self.pixelHeight=transform_ds[5]   # resolution in y direction
        # read data. Returns as a 2D numpy array
        self.data=ds.GetRasterBand(1).ReadAsArray(0,0,self.nX,self.nY)
        
############################################################################
    def raster2array(self,filename):  # a method to open tiff and get values as an array
        # open tiff
        raster = gdal.Open(filename)
        #get the band 1 information, actually the defult band in the tiff is 1
        band = raster.GetRasterBand(1)
        # give a return value as an array
        return band.ReadAsArray()
############################################################################
    def adjust(self,raster1,raster2):
        '''
        a function for adjuest the direction of x axis if it is diffferent in two tiff rasters
        '''
        if direction_x_raster1 != direction_x_raster2:
            #adjust to ensure the direction of rasters is the same
            adjust raster1 & raster2
############################################################################

    def findIntersection(self,i,j,x_real,y_real):
        '''
        i,j is the x,y in pixel coordinate system
        x_real is x value in real projection
        y_real is y value in real projection
        '''
        #x_real1 is real x for tiff file 1
        x_real1 = raster1.x
        #y_real1 is real y for tiff file 1
        y_real1 = raster1.y
        #x_real2 is real x for tiff file 2
        x_real2 = raster2.x
        #y_real2 is real y for tiff file 2
        y_real2 = raster2.y
        #pixel size in x direction in tiff file 1
        pixelX = np.size(x_real1)
        #pixel size in y direction in tiff file 1
        pixelY = np.size(y_real1)
        # make a loop
        for i in range(pixel_X):
            for j in range(pixelY):
                # if the lower left point in tiff file 2 is included in tiff file 2
                if (x_real2>x_real1 & x_real2<x_real1+i & y_real2>y_real1 & y_real2<y_real1+j):
                    #get the lower left coordinate of tiff file 2
                    print(x_real2,y_real2)
                    return x_real2,x_real1+i,y_real2,yreal1+j
############################################################################

if __name__=="__main__":
    '''
    main part
    '''
    #input file
    filename1 = '1.tif'
    filename2 = '2.tif'
    f = task3(filename)
    #use functions above
    f.readTiff()
    f.raster2array()
    f.findIntersection()

