'''
import packages
'''
from lvisClass import lvisData
from tiffHandle import Transform
import argparse
from processLVIS import lvisGround
import numpy as np
from osgeo import gdal  
from osgeo import osr  
#######################################################
def writeTiff(data,x,y,res,outname):
        '''
        Make a geotiff from an array of points
        '''
        # determine bounds
        minX=np.min(x)
        maxX=np.max(x)
        minY=np.min(y)
        maxY=np.max(y)
          
        # determine image size
        nX=int((maxX-minX)/res+1)
        nY=int((maxY-minY)/res+1)
        
        # pack in to array
        imageArr=np.full((nY,nX),-999.0)        # make an array of missing data flags
        xInds=np.array((x-minX)/res,dtype=int)  # determine which pixels the data lies in
        yInds=np.array((maxY-y)/res,dtype=int)  # determine which pixels the data lies in
        # this is a simple pack which will assign a single footprint to each pixel

        imageArr[yInds,xInds]=data
        #print(imageArr)
        # set geolocation information (note geotiffs count down from top edge in Y)
        geotransform = (minX, res, 0, maxY, 0, -res)

        # load data in to geotiff object
        dst_ds = gdal.GetDriverByName('GTiff').Create(outname, nX, nY, 1, gdal.GDT_Float32)

        dst_ds.SetGeoTransform(geotransform)    # specify coords
        srs = osr.SpatialReference()            # establish encoding
        srs.ImportFromEPSG(3031)                # WGS84 lat/long
        dst_ds.SetProjection(srs.ExportToWkt()) # export coords to file
        dst_ds.GetRasterBand(1).WriteArray(imageArr)  # write image to the raster
        dst_ds.GetRasterBand(1).SetNoDataValue(-999)  # set no data value
        dst_ds.FlushCache()                     # write to disk
        dst_ds = None
        
        print("Image written to",outname)
        return
#######################################################
def readCommands():
    '''
    Read commandline arguments
    '''
    p = argparse.ArgumentParser(description=("Handle LVIS"))
    #set input
    p.add_argument("--input", dest ="filename", type=str, default='/geos/netdata/avtrain/data/3d/oosa/assignment/lvis/2015/ILVIS1B_AQ2015_1017_R1605_058236.h5', help=("Input filename"))
    #set output
    p.add_argument("--output", dest ="outname", type=str, default='ILVIS1B_AQ2015_1017_R1605_058236.h5', help=("Output filename"))    
    #set resolution
    p.add_argument("--res", dest ="res",type=int, default=200, help=("Resolution"))
    cmdargs = p.parse_args()
    return cmdargs
        
if __name__=="__main__":
    #use readCommands method
    cmd=readCommands()
    filename = cmd.filename
    outname = cmd.outname
    res = cmd.res
    # print method
    '''
    make a loop to draw tiff by dividing into 15 parts
    to avoid too much RAM and killed
    '''
    #use new zG to hold all zG values in a 15*15 image
    zG = []
    #use new lon to hold all lon values in a 15*15 image
    lon = []
    #use new lon to hold all lon values in a 15*15 image
    lat = []
    #loop 15 times
    for i in range(15):
        for j in range(15):
            #get data
            b = lvisData(filename,onlyBounds=True)
            #divide into 15 parts
            x0 = (b.bounds[2]-b.bounds[0])*i/15+b.bounds[0]
            y0 = (b.bounds[3]-b.bounds[1])*j/15+b.bounds[1]
            x1=(b.bounds[2]-b.bounds[0])*(i+1)/15+b.bounds[0]
            y1=(b.bounds[3]-b.bounds[1])*(j+1)/15+b.bounds[1]
            
            
            # read in bounds
            lvis=lvisGround(filename,minX=x0,minY=y0,maxX=x1,maxY=y1)
            #get value when readLVIS data
            a = lvis.readLVIS(filename,minX=x0,minY=y0,maxX=x1,maxY=y1,onlyBounds=False)
            #if readLVIS return 'a' value means LVIS data have data
            if (a):
                #print the coordinate in 15*15 grid
                print([i,j])
                #reroject the result, 3031 is a Antartica metric projection
                lvis.reproject(4326,3031)
                #process lvis data to get useful spatial information
                lvis.setElevations()
                data = lvis.estimateGround()
                #write a tiff file
                b = Transform(filename)
                #add all zG into this zG
                zG = np.append(zG,lvis.zG)
                #add all lon into this lon
                lon = np.append(lon,lvis.lon)
                #add all lat into this lat
                lat = np.append(lat,lvis.lat)
            else:
                
                #if readLVIS return a opposite 'a' value
                print('No data')
    #write a tiff for total zG,total lon,total lat values
    writeTiff(zG,lon,lat,res=200,outname=outname+str(i)+str(j)+'.tif')

    