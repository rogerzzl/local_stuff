'''
some methods for gap-fill operation
'''
import gdal, ogr, osr, os
import numpy as np
############################################################################

def raster2array(rasterfn):  # a method to open tiff and get values as an array
    # open tiff
    raster = gdal.Open(rasterfn)
    #get the band 1 information, actually the defult band in the tiff is 1
    band = raster.GetRasterBand(1)
    # give a return value as an array
    return band.ReadAsArray()
############################################################################
    
def getNoDataValue(rasterfn): # a method to get nodata part in tiff
    # open tiff
    raster = gdal.Open(rasterfn) 
    band = raster.GetRasterBand(1)
    # use GetNoDataValue to get no data
    return band.GetNoDataValue()
############################################################################

def array2raster(rasterfn,newRasterfn,array): # a method that transfer array to raster tiff
    raster = gdal.Open(rasterfn)
    #get the transform information
    geotransform = raster.GetGeoTransform()
    #get x value
    originX = geotransform[0]
    #get y value
    originY = geotransform[3]
    # get pixel width
    pixelWidth = geotransform[1]
    #get pixel height
    pixelHeight = geotransform[5]
    #record colums
    cols = raster.RasterXSize
    #record rows
    rows = raster.RasterYSize
    '''
    write tiff part
    '''
    driver = gdal.GetDriverByName('GTiff')
    outRaster = driver.Create(newRasterfn, cols, rows, 1, gdal.GDT_Float32)
    outRaster.SetGeoTransform((originX, pixelWidth, 0, originY, 0, pixelHeight))
    outband = outRaster.GetRasterBand(1)
    outband.WriteArray(array)
    outRasterSRS = osr.SpatialReference()
    outRasterSRS.ImportFromWkt(raster.GetProjectionRef())
    outRaster.SetProjection(outRasterSRS.ExportToWkt())
    outband.FlushCache()
############################################################################
    
if __name__=="__main__":
    '''
    main part
    '''
    # set input file
    rasterfn = 'ILVIS1B_AQ2015_1017_R1605_058236.h51414.tif'
    #set a new value to replace no data
    for i in range(len(raster2array(rasterfn))):
        #new value is a mean value of pixels in a 15*15 window
        newValue = np.mean(raster2array(rasterfn)[i]/15)
    # set output file
    newRasterfn = 'interp_2015.tif'
    
    # Convert Raster to array
    rasterArray = raster2array(rasterfn)
    
    # Get no data value of array
    noDataValue = getNoDataValue(rasterfn)
    
    # Updata no data value in array with new value
    rasterArray[rasterArray == noDataValue] = newValue
    
    # Write updated array to new raster
    array2raster(rasterfn,newRasterfn,rasterArray)