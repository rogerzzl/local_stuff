'''
import packages
'''
import gdal
import matplotlib.pyplot as plt
import numpy as np
############################################################################
def raster2array(rasterfn):
    '''
    a function to tranform raster to an array
    '''
    raster = gdal.Open(rasterfn)
    #defult band is 1
    band = raster.GetRasterBand(1)
    array = band.ReadAsArray()
    #iterate over all data by pixel
    for i in range(pixel):
        if some values are same:
            #print the x and y of same values
            print(x,y in same value)
    return x,y
############################################################################
def drawContour(x,y):
    '''
    a function to draw contour line
    '''
    #set a draw start point
    if x is smallest than other x in same pixel value:
        start_x = x
    # append new x values
    total_x = np.append(x,samevalue x)
    plt.plot(start_x,total_x)

def DP_line(ix,iy,x,y,node):
    '''
    line generalisation function
    '''
    #check the whether points are adjacent,if yes,stop
    if ix-iy < 2:
        return
    #calculate the distance between points and each line.
    distacne(x,y,line)
    #find the max distance
    maxDis = np.max(distance)
    #if distance beyond tolerance,add a node 
    if maxDis biger:
        #add node
        add a node
        #print node and coordinate
        print(node,x,y)
        # append node
        node = np.append(node)
        #generate those nodes
        DP_line(x,y,node)

if __name__=="__main__":
    '''
    main part
    '''
    file = raster2array('.tif')
    drawContour()
    DP_line()
    
    
    