'''
import packages
'''
from lvisClass import lvisData
from tiffHandle import Transform
import argparse
from processLVIS import lvisGround

def readCommands():
    '''
    Read commandline arguments
    '''
    p = argparse.ArgumentParser(description=("Handle LVIS"))
    #set input
    p.add_argument("--input", dest ="filename", type=str, default='/geos/netdata/avtrain/data/3d/oosa/assignment/lvis/2009/ILVIS1B_AQ2009_1020_R1408_071909.h5', help=("Input filename"))
    #set output
    p.add_argument("--output", dest ="outname", type=str, default='ILVIS1B_AQ2009_1020_R1408_071909.h5', help=("Output filename"))
    #set resolution
    p.add_argument("--res", dest ="res",type=int, default=10, help=("Resolution"))
    cmdargs = p.parse_args()
    return cmdargs

if __name__=="__main__":
    #use readCommands method
    cmd=readCommands()
    filename = cmd.filename
    outname = cmd.outname
    res = cmd.res
    # print method
    '''
    make a loop to draw tiff by dividing into 15 parts
    to avoid too much RAM and killed
    '''
    #loop 15 times
    for i in range(15):
        for j in range(15):
            #get data
            b = lvisData(filename,onlyBounds=True)
            #divide into 15 parts
            x0 = (b.bounds[2]-b.bounds[0])*i/15+b.bounds[0]
            y0 = (b.bounds[3]-b.bounds[1])*j/15+b.bounds[1]
            x1=(b.bounds[2]-b.bounds[0])*(i+1)/15+b.bounds[0]
            y1=(b.bounds[3]-b.bounds[1])*(j+1)/15+b.bounds[1]


            # read in bounds
            lvis=lvisGround(filename,minX=x0,minY=y0,maxX=x1,maxY=y1)
            #get value when readLVIS data
            a = lvis.readLVIS(filename,minX=x0,minY=y0,maxX=x1,maxY=y1,onlyBounds=False)
            #if readLVIS return 'a' value means LVIS data have data
            if (a):
                #print the coordinate in 15*15 grid
                print([i,j])
                #reroject the result, 3031 is a Antartica metric projection
                lvis.reproject(4326,3031)
                #process lvis data to get useful spatial information
                lvis.setElevations()
                data=lvis.estimateGround()
                #write a tiff file
                b=Transform(filename)
                b.writeTiff(data,lvis.lon,lvis.lat,res,outname=outname+str(i)+str(j)+'.tif')

            else:
                #if readLVIS return a opposite 'a' value
                print('No data')


    
