import glob
import os
from scipy import misc

file_list = misc.imread(".\2015\*.tif")
files_string = "".join(file_list)
command = "gdal_merge.py -o 2015_merge.tif -of gtiff" + files_string
os.system(command)

